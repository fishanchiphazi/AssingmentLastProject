import React, {component}  from 'react';
import logo from './logo.svg';
import './App.css';
 
class App extends component {
  render() {
  return   (
    <div className="App">
      <h1> hello from react</h1> 
   <form>
   <input type="text" ref="name" />
   <input type="text" ref="complited" />
   <button onclick={this.addTodo}>Add  </button>
   </form>
   </div> 
    ); 
  }   
}
export default App;