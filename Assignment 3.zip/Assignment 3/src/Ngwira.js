import React, {component}  from 'react';
import './App.css';
 
class App extends component {
  render() {
  return   (
    <div className="App">
    <h1> hello from react </h1>
      
   </div> 
    ); 
  }   
}
export default App;