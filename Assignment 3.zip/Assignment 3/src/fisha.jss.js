import React, {component}  from 'react';
import logo from './logo.svg';
import './App.css';
 
class App extends component {
  render() {
  return   (
    <div className="App">
   </div>
   
  }   
}
export default App;