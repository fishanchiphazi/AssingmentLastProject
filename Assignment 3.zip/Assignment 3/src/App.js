import React, {Component} from 'react';
import './App.css';

class App extends Component {
  details(index) {
    let todos = this.state.todos;

    let todo = todos.find(function(todo) {
      return todo.counter == index
    });
    console.log('you are clicking on ' );
    console.log(todo);
  }

  removeTodo(index) {
    let todos = this.state.todos;

    let todo = todos.find(function(todo) {
      return todo.counter == index
    });
     
    todos.splice(todo,1);

    this.setState({
      todos: todos
    });

  }
   addTodo(event) {
     event.preventDefault();
     let name = this.refs.name.value;
     let completed = this.refs.completed.value;
     let counter = this.state.counter;
    let todo = {
       name,
       completed,
       counter
     };
     counter+=1;
     let todos = this.state.todos;
     todos.push(todo);
     this.setState({
     todos: todos,
     counter: counter

     });

     
      this.refs.todoForm.reset();

    }

  constructor() {
    super();
    this.addTodo = this.addTodo.bind(this);
    this.removeTodo = this.removeTodo.bind(this);
    this.details = this.details.bind(this);
    this.state = {
    
      todos: [],
      title: 'STATISTICS DEPARTMENT'
    }
  }
  
  
  render() {
    let title = this.state.title;
    let todos = this.state.todos;
    return ( 
      <div className="App">
      <div className="container">
      <div>
      <div >
      <h1>{title}</h1>
      </div>
       <form ref="todoForm" className='todoForm'>
         <input type= "text" ref="name" placeholder="How old are you?"/><br /><br />
         <input type="text" ref="completed" placeholder="Yes" /><br /><br />
         <button onClick={this.addTodo}>Add </button>
     
       <ul>
         {todos.map((todo=> <li key={todo.counter}>{todo.name}</li>))}<br />
         <button onClick={this.removeTodo.bind(null,todos.counter)}>Remove </button>
         </ul>
         </form>
         </div>
         </div>
      </div>
    );
  }
}

  export default App;

